module.exports = 'local-tgz@1.0.0'
