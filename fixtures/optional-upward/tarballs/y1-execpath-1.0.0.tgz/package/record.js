const cp = require('child_process')
const p = process.env.npm_execpath
const v = cp.execFileSync(process.execPath, [p, '--version']).toString()
require('fs').writeFileSync('execpath.txt', p + '\n' + v)
