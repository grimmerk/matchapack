module.exports = 'lc-s';
