module.exports = 'scoped'
