module.exports = 'lc-r';
