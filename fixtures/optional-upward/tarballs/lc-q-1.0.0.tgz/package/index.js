module.exports = 'lc-q';
