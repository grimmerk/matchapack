const fs = require('fs'), path = require('path')
const d = path.join('built', process.cwd())
fs.mkdirSync(d, { recursive: true })
fs.writeFileSync(path.join(d, 'marker'), 'x\n')
